# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
GetThereApp::Application.config.secret_key_base = '962d576c5b95bbb58625fbd4eb7901b93f3a3110789da9b2cb1a6925ab4aa63a8240da34cd1fbeda807556cf9b24488b144dbcc425ac83aa28f45708783ca2e0'
